package web;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class RegistrationService {
	
	private String  firstName,lastName,mail_Id,phoneNo;

	public RegistrationService(String firstName, String lastName, String mail_Id, String phoneNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mail_Id = mail_Id;
		this.phoneNo = phoneNo;
	}
	
	public void adduser() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/nissan", "root", "admin");
			
			Statement st=con.createStatement();
			st.executeUpdate("insert into register values('"+firstName+"','"+lastName+"','"+mail_Id+"','"+phoneNo+"')");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ResultSet getdetails() {
		ResultSet r = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/nissan", "root", "admin");
			
			Statement st=con.createStatement();
			r=st.executeQuery("select * from register");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return r;
		
	}

}
